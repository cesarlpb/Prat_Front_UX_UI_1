INSERT INTO usuarios (nombre, email) VALUES ('Ana2', 'ana2@example.com');

INSERT INTO usuarios (nombre, email) VALUES ('Luis', 'Luis@example.com');

INSERT INTO usuarios (nombre, email) VALUES ('Larry Kapaja', 'larry@example.com');


DELETE FROM usuarios WHERE id = 1;
